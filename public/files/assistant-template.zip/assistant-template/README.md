1. pnpm install
2. pnpm tauri dev (dostosuj do siebie)
3. pnpm tauri build
