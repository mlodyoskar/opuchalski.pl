import { useConfigStore } from "@/lib/stores/main";
import { IMessage } from "@/lib/stores/main.dt";
import { cn } from "@/lib/utils";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ScrollArea } from "./ui/scroll-area";

interface MessagesProps {
 messages: IMessage[];
}

export const Messages = ({ messages }: MessagesProps) => {
 const filteredMessages = messages.filter(
  (message) => message.role !== "system"
 );
 const { snippetsOpen: isOpen } = useConfigStore();

 return (
  <ScrollArea
   className={cn("overflow-hidden h-[550px]", isOpen && "h-[400px]")}
  >
   <div className="grid grid-cols-12 gap-y-2">
    {filteredMessages.map(({ content, role }) => {
     if (role === "assistant") {
      return (
       <div key={content} className="col-start-1 col-end-12  rounded-lg">
        <div className="flex flex-row">
         <div className="relative text-left text-sm bg-white py-2 px-4 overflow-hidden	 border rounded-xl">
          <Markdown remarkPlugins={[remarkGfm]}>{content}</Markdown>
         </div>
        </div>
       </div>
      );
     } else {
      return (
       <div key={content} className="col-start-2 col-end-13  rounded-lg">
        <div className="flex items-center justify-start flex-row-reverse">
         <div className="relative text-left mr-3 text-sm bg-blue-100 py-2 px-4  shadow rounded-xl">
          <div>{content}</div>
         </div>
        </div>
       </div>
      );
     }
    })}
   </div>
  </ScrollArea>
 );
};
