"use client";

import { Button } from "@/components/ui/button";
import { saveState, useConfigStore } from "@/lib/stores/main";
import { ArrowBigLeft } from "lucide-react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
 Form,
 FormControl,
 FormField,
 FormItem,
 FormLabel,
 FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";

const settingsFormSchema = z.object({
 apikey: z.string(),
});

const SettingsPage = () => {
 const { apikey } = useConfigStore();

 const form = useForm<z.infer<typeof settingsFormSchema>>({
  resolver: zodResolver(settingsFormSchema),
  defaultValues: {
   apikey,
  },
 });

 const onSubmit = async (values: z.infer<typeof settingsFormSchema>) => {
  console.log(values);
  useConfigStore.setState((state) => ({ ...state, apikey: values.apikey }));

  const store = useConfigStore.getState();

  await saveState(store);

  toast({
   title: "Saved your settings",
   description: "Your settings have been saved to persistant store.",
  });
 };

 return (
  <div className="p-8 w-full">
   <Button className="ml-auto" variant="outline" size="icon" asChild>
    <Link href="/">
     <ArrowBigLeft />
    </Link>
   </Button>
   <Form {...form}>
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
     <FormField
      control={form.control}
      name="apikey"
      render={({ field }) => (
       <FormItem>
        <FormLabel>OpenAI API key</FormLabel>
        <FormControl>
         <Input placeholder="Your key..." {...field} />
        </FormControl>
        <FormMessage />
       </FormItem>
      )}
     />

     <Button type="submit">Save</Button>
    </form>
   </Form>
  </div>
 );
};

export default SettingsPage;
