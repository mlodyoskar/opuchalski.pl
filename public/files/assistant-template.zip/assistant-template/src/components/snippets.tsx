import { useConfigStore } from "@/lib/stores/main";
import {
 ChevronDownIcon,
 ChevronUpIcon,
 LanguagesIcon,
 MessageCircleIcon,
} from "lucide-react";
import { SectionHeader } from "./section-header";
import { ScrollArea } from "./ui/scroll-area";
import { useState } from "react";
import { cn } from "@/lib/utils";

const snippets = [
 {
  id: 1,
  name: "Yes/No",
  snippet: "Answer question with YES or NO.",
  icon: <MessageCircleIcon />,
 },
 {
  id: 2,
  name: "Translate",
  snippet:
   "Translate the following text from English to Polish or vice versa while ensuring that the context of the text remains the same.",
  icon: <LanguagesIcon />,
 },
];

const useSnippets = () => {
 const [selectedSnippet, setSelectedSnippet] = useState<number | null>(null);

 const toggleOpen = () => {
  useConfigStore.setState((state) => ({
   ...state,
   snippetsOpen: !state.snippetsOpen,
  }));
 };

 const selectSnippet = (id: number) => {
  const snippet = snippets.find((snippet) => snippet.id === id);

  if (!snippet) return;

  if (selectedSnippet === id) {
   setSelectedSnippet(null);
   useConfigStore.setState((state) => ({ ...state, snippet: "" }));
   return;
  }
  useConfigStore.setState((state) => ({
   ...state,
   snippet: snippet.snippet,
  }));

  setSelectedSnippet(id);
 };

 return {
  selectedSnippet,
  selectSnippet,
  toggleOpen,
 };
};

export const Snippets = () => {
 const { snippetsOpen: isOpen } = useConfigStore();
 const { toggleOpen, selectSnippet, selectedSnippet } = useSnippets();
 return (
  <section>
   <SectionHeader className="mb-2">
    Snippets{" "}
    <button onClick={toggleOpen}>
     {isOpen ? (
      <ChevronDownIcon className="w-5" />
     ) : (
      <ChevronUpIcon className="w-5" />
     )}
    </button>
   </SectionHeader>
   {isOpen && (
    <ScrollArea className="max-h-40">
     <div className="grid grid-cols-6 gap-2 mb-5">
      {snippets.map(({ id, name, icon }) => {
       const selected = selectedSnippet === id;

       return (
        <button
         key={id}
         onClick={() => selectSnippet(id)}
         className={cn(
          "col-span-1 bg-white  flex items-center flex-col shadow rounded-lg p-2",
          selected && "bg-blue-400 text-white"
         )}
        >
         {icon}
         <p className="text-sm">{name}</p>
        </button>
       );
      })}
     </div>
    </ScrollArea>
   )}
  </section>
 );
};
