"use client";

import "./globals.css";
import { ChangeEvent } from "react";
import { useConfigStore } from "@/lib/stores/main";
import { ask } from "@/lib/functions/chat";
import { SectionHeader } from "@/components/section-header";
import { Snippets } from "@/components/snippets";

import { Header } from "@/components/header";
import { Messages } from "@/components/messages";
import { Prompt } from "@/components/prompt";

const MainPage = () => {
 const state = useConfigStore();

 const handleUpdateQuery = (e: ChangeEvent<HTMLInputElement>) => {
  useConfigStore.setState((state) => ({ ...state, query: e.target.value }));
 };

 console.log(state);

 const handleSubmit = async (e: ChangeEvent<HTMLFormElement>) => {
  e.preventDefault();
  await ask(state);
 };

 const newChat = () => {
  useConfigStore.setState((state) => ({
   ...state,
   messages: state.messages.slice(0, 1),
  }));
 };

 //   document.addEventListener('keydown', sendShortcut);

 //   async function sendShortcut(event) {
 //     if (event.key === 'Enter' && event.metaKey) {
 //       await ask(currentState);
 //     }
 //   }

 //   const unsubscribe = state.subscribe((current) => {
 //     currentState = {
 //       ...current,
 //       messages: [
 //         ...current.messages
 //       ],
 //       shortcuts: [
 //         ...current.shortcuts
 //       ]
 //     };
 //     model = current.model;
 //     messages = current.messages;
 //     apikey = current.apikey;
 //     stream = current.stream;
 //     query = current.query
 //   });

 //   onMount(async () => {

 //     await unregisterAll();
 //     currentState.shortcuts.forEach(shortcut => {
 //       registerKeystroke(currentState, shortcut);
 //     })
 //   });

 //   onDestroy(() => {
 //     unsubscribe();
 //     currentState.shortcuts.forEach(shortcut => {
 //       unregisterKeystroke(shortcut);
 //     })
 //   });

 return (
  <main className="h-screen overflow-hidden">
   <div className="text-center  p-8 pt-2 h-full">
    <div className="flex flex-col h-full">
     <Header />
     <Snippets />
     <div className="flex-grow">
      <SectionHeader className="mb-2">Chat</SectionHeader>

      <Messages messages={state.messages} />
     </div>
     <div className="absolute flex flex-col bottom-4 right-0 left-0 max-w-xl mx-auto">
      <Prompt
       prompt={state.query}
       onPromptChange={handleUpdateQuery}
       onSubmit={handleSubmit}
      />
      <button onClick={newChat} className="mr-auto p-0 text-sm">
       New chat
      </button>
     </div>
    </div>
   </div>
  </main>
 );
};

export default MainPage;
