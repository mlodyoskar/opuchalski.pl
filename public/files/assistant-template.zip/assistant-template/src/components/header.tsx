import Link from "next/link";
import { Button } from "./ui/button";
import { Popover, PopoverTrigger, PopoverContent } from "./ui/popover";
import { useConfigStore } from "@/lib/stores/main";
import { BracesIcon, Settings2Icon } from "lucide-react";

export const Header = () => {
 const state = useConfigStore();
 return (
  <header className="flex items-center justify-between mb-6">
   <div className="flex gap-2">
    <img
     className="w-12 h-12 rounded-full block"
     alt="Jarvis."
     src="/app-icon.png"
    />
    <div className="text-left">
     <p className="text-sm opacity-50">Your AI assistant</p>
     <h1 className="">AI Assistant</h1>
    </div>
   </div>
   <div>
    <Button asChild size="icon" variant="ghost">
     <Link href={"/settings"}>
      <Settings2Icon />
     </Link>
    </Button>
    <Popover>
     <PopoverTrigger asChild>
      <Button size="icon" variant="ghost">
       <BracesIcon />
      </Button>
     </PopoverTrigger>
     <PopoverContent className="w-[600px] h-[700px]">
      <pre className="text-xs h-[650px] overflow-scroll whitespace-break-spaces">
       {JSON.stringify(state, null, 2)}
      </pre>
     </PopoverContent>
    </Popover>
   </div>
  </header>
 );
};
