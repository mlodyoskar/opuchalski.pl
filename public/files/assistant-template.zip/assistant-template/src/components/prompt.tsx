import { SendIcon } from "lucide-react";
import { ChangeEvent } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

interface PromptProps {
 prompt: string;
 onPromptChange: (e: ChangeEvent<HTMLInputElement>) => void;
 onSubmit: (e: ChangeEvent<HTMLFormElement>) => void;
}

export const Prompt = ({ prompt, onPromptChange, onSubmit }: PromptProps) => {
 return (
  <form onSubmit={onSubmit} className="flex gap-1">
   <Input
    value={prompt}
    onChange={onPromptChange}
    placeholder="Ask me anything..."
    className="p-3.5"
    name="prompt"
   ></Input>
   <div className="text-right">
    <Button size="icon">
     <SendIcon />
    </Button>
   </div>
  </form>
 );
};
