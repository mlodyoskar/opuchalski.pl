import { Store } from "tauri-plugin-store-api";
import type { IState } from "./main.dt";
import { create } from "zustand";

let store = new Store(".assistant.dat");

export const defaultSystemPrompt =
 "You're a helpful assistant named 'AI Assistant'. You answer question briefly. You talk to Oskar, you always talk to him in person.";

export const saveState = async (newState: Partial<IState>) => {
 try {
  await store.set("state", newState);
 } catch (error) {
  console.error(error);
 }
 return newState;
};

export const loadState = async () => {
 const savedState: IState | null = await store.get("state");
 if (!savedState) {
  throw new Error("No saved state found");
 }
 console.log(savedState);

 const configStore = useConfigStore;
 configStore.setState((state) => ({ ...state, apikey: savedState.apikey }));
};

export const useConfigStore = create<IState>((set) => ({
 apikey: "",
 model: "gpt-3.5-turbo",
 max_tokens: 1500,
 temperature: 0.8,
 stream: true,
 answer: "",
 query: "",
 snippetsOpen: false,
 snippet: "",
 messages: [
  {
   role: "system",
   content: defaultSystemPrompt,
  },
 ],
 shortcuts: [
  {
   id: 1,
   system: "Answer yes or no.",
   name: "Yes or no",
   keystroke: "CommandOrControl+Shift+K",
  },
 ],
}));
