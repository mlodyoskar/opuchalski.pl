import { displayAnswer, openAICompletion } from "./openai";
import { IMessage, IState } from "../stores/main.dt";
import { useConfigStore } from "../stores/main";

export const generateAnswer = async (currentState: IState) => {
 console.log(currentState);

 const response = await openAICompletion({
  apikey: currentState.apikey,
  stream: currentState.stream,
  messages: currentState.messages,
 });
 if (response.ok) {
  await displayAnswer({ stream: currentState.stream }, response);
 } else {
  console.error("An error occurred during OpenAI request", response.statusText);
 }
};

export const ask = async (currentState: IState) => {
 if (!currentState.query) {
  return;
 }
 const { snippet, query, messages } = currentState;

 const systemMessageWithSnippet = snippet
  ? {
     role: "system" as IMessage["role"],
     content: snippet,
    }
  : null;

 const userMessage = {
  role: "user" as IMessage["role"],
  content: query,
 };

 const updatedMessages = systemMessageWithSnippet
  ? [...messages, systemMessageWithSnippet, userMessage]
  : [...messages, userMessage];

 const updatedState = {
  ...currentState,
  messages: updatedMessages,
  query: "",
 };

 useConfigStore.setState(updatedState);
 await generateAnswer(updatedState);
};
