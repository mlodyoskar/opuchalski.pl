import { cn } from "@/lib/utils";
import { Separator } from "./ui/separator";

interface Props {
 children: React.ReactNode;
 className?: string;
}

export const SectionHeader = ({ children, className }: Props) => {
 return (
  <div className={cn("flex items-center", className)}>
   <Separator className="flex-grow w-auto" />
   <h2 className="text-zinc-600 px-4 flex items-center">{children}</h2>
   <Separator className="flex-grow w-auto" />
  </div>
 );
};
