"use client";

import { Toaster } from "@/components/ui/toaster";
import { loadState } from "@/lib/stores/main";
import { Inter } from "next/font/google";
import { useEffect } from "react";

const inter = Inter({ subsets: ["latin"] });

export default function RootLayout({
 children,
}: {
 children: React.ReactNode;
}) {
 useEffect(() => {
  const load = async () => {
   await loadState();
  };

  load();
 }, []);

 return (
  <html className="h-full" lang="en">
   <body className={`${inter.className} h-full`}>
    {children}
    <Toaster />
   </body>
  </html>
 );
}
